// src/controllers/mainController.js

exports.getHome = (req, res) => {
    res.send('Controlador funcionando');
};
